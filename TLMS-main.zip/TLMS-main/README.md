# TLMS
The Library Management Systen (Using Django | Python | SQLite)
+-------=---+------------+----------+
| user      | usernames  | password | 
| admin     | admin      | admin    |
| student   | 22ceuod010 | tirth    |
| librarian | lib1       | lib1     |
+-----------+------------+----------+

features for student :
login/register
search book
request book
view profile
change password
history
view due books
logout

features for librarian :
login/register
search book
view profile
change password
issue book
reissue/return book
view issues
view students
logout

features for admin : 
All CRUD operations on all entities
generate reports

